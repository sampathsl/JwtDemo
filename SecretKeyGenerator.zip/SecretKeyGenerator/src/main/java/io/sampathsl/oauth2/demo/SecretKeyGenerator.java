package io.sampathsl.oauth2.demo;

import java.security.Key;
import java.util.Base64;

import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;

public class SecretKeyGenerator {
  public static void main(String[] args) {
    final Key key = Keys.secretKeyFor(SignatureAlgorithm.HS512);
    final byte[] keyBytes = key.getEncoded();
    final String base64SecretKey = Base64.getEncoder().encodeToString(keyBytes);
    System.out.println("Base64 Secret Key: " + base64SecretKey);
  }
}
